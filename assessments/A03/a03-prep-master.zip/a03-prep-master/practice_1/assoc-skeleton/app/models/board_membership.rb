class BoardMembership < ApplicationRecord
end
