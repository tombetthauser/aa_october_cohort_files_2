class Company < ApplicationRecord
end
