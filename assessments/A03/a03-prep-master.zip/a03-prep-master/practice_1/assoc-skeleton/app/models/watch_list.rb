class WatchList < ApplicationRecord
end
