class Exchange < ApplicationRecord
end
