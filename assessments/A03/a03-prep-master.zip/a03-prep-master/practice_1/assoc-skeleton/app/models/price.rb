class Price < ApplicationRecord
end
