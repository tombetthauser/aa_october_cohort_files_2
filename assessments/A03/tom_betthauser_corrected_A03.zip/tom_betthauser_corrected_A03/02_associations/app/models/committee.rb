# == Schema Information
#
# Table name: committees
#
#  id             :integer          not null, primary key
#  name           :string
#  mandate        :string
#  chairperson_id :integer
#  created_at     :datetime         not null
#  updated_at     :datetime         not null
#

class Committee < ApplicationRecord


    belongs_to :chairperson,
        foreign_key: :chairperson_id,
        class_name: :Senator

# -------------

    has_many :memberships,
        foreign_key: :committee_id,
        class_name: :CommitteeMembership


# -----------------

    has_many :senators,
        through: :memberships,
        source: :senator

    # has_many :,
    #     through: :,
    #     source: :

end
