# == Schema Information
#
# Table name: parties
#
#  id              :integer          not null, primary key
#  name            :string
#  color           :string
#  ideology_id     :integer
#  party_leader_id :integer
#  created_at      :datetime         not null
#  updated_at      :datetime         not null
#

class Party < ApplicationRecord


    belongs_to :ideology,
        foreign_key: :ideology_id,
        class_name: :Ideology
        
    belongs_to :party_leader,
        foreign_key: :party_leader_id,
        class_name: :Senator

# # ------------------


    has_many :senators,
        foreign_key: :party_id,
        class_name: :Senator



    # has_many :,
    #     through: :,
    #     source: :


end
