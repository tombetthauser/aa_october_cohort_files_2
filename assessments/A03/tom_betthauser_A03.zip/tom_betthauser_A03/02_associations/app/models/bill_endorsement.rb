# == Schema Information
#
# Table name: bill_endorsements
#
#  id         :integer          not null, primary key
#  bill_id    :integer
#  senator_id :integer
#  created_at :datetime         not null
#  updated_at :datetime         not null
#

class BillEndorsement < ApplicationRecord

    belongs_to :bill,
        foreign_key: :bill_id,
        class_name: :Bill

    belongs_to :senator,
        foreign_key: :senator_id,
        class_name: :Senator

# ------------------

    has_many :bills,
        foreign_key: :author_id,
        class_name: :Bill

    
end
