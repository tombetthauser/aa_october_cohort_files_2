// Write a function, `uniqueSubstrings(string)`, that returns an array
// containing the unique substrings of `string`.

function uniqueSubstrings(str) {
    let rarr = [];
    for (let i = 0; i < str.length; i++) {
        for (let j = i; j < str.length; j++) {
            let sub = str.slice(i, j+1);
            if (!rarr.includes(sub)) rarr.push(sub);
        }
    }
    return rarr;
}



// Write an Array method, `Array.prototype.myEach(callback)`, that passes each 
// element to `callback` before returning the original array. Do NOT call the 
// built-in `Array.prototype.forEach` method in your implementation.

Array.prototype.myEach = function(call) {
    for (let i = 0; i < this.length; i++) call(this[i]);
    return this;
}


// Write an Array method, `Array.prototype.myFilter(callback)`, that returns an 
// array made up of the elements in the original array for which `callback` 
// returns `true`. Use the `Array.prototype.myEach` method you defined above. 
// Do NOT call the built-in `Array.prototype.forEach` or `Array.prototype.filter` 
// methods in your implementation.

Array.prototype.myFilter = function(call) {
    let rarr = [];
    this.myEach( ele => {
        if (call(ele)) rarr.push(ele)
    });
    return rarr;
}



// Write a function `pairMatch(array, callback)`. It should return all pairs
// of indices ([i, j]) for which `callback(array[i], array[j])` returns true.
// NB: Keep in mind that the order of the arguments to the callback may matter.
// e.g., callback = function(a, b) { return a < b }

function pairMatch(arr, call) {
    let rarr = [];
    for (let i = 0; i < arr.length; i++) {
        for (let j = 0; j < arr.length; j++) {
            if (call(arr[i], arr[j]) && i !== j) {
                rarr.push([i,j])
            };
        }
    }
    return rarr;
}

// function sum(x, y) { return x + y === 0; }

// console.log(pairMatch([1, 0, -1], sum)




// Write an Array method, `Array.prototype.bubbleSort(callback)`, that bubble 
// sorts an array. It should take an optional callback which compares two 
// elements, returning -1 if the first element should appear before the second, 
// 0 if they are equal, and 1 if the first element should appear after the second. 
// Do NOT call the built-in Array.prototype.sort method in your implementation. 
// Also, do NOT modify the original array.
//
// Here's a quick summary of the bubble sort algorithm:
//
// Iterate over the elements of the array. If the current element is unsorted
// with respect to the next element, swap them. If any swaps are made before
// reaching the end of the array, repeat the process. Otherwise, return the
// sorted array.

Array.prototype.bubbleSort = function(call) {
    call = call || function(a,b) {if (a < b) return -1};
    let copy = this.slice();
    let sorted = false;
    while (!sorted) {
        sorted = true;
        for (let i = 0; i < copy.length - 1; i++) {
            if (call(copy[i], copy[i+1]) !== -1) {
                [copy[i+1], copy[i]] = [copy[i], copy[i+1]]
                sorted = false;
            }
        }
    }
    return copy;
}


// Write a Function method, `Function.prototype.myBind(context, bindArgs)`. It
// should return a copy of the original function, where `this` is set to `context`.

Function.prototype.myBind = function(cont, ...bargs) {
    let that = this;
    return function(...cargs) {
        return that.apply(cont, bargs.concat(cargs));
    }
}


// Write a Function method, `Function.prototype.inherits(ParentClass)`. It 
// should extend the methods of `ParentClass.prototype` to the constructor 
// function it is called on.

Function.prototype.inherits = function(parent) {
    function Surrogate() {};
    Surrogate.prototype = parent.prototype;
    this.prototype = new Surrogate;
    this.constructor = this;
}


// Write a function, `myCurry(fn, object, numArgs)`, that curries the
// function. Remember that a curried function is invoked with one argument at a
// time. For example, the curried form of `sum(1, 2, 3)` would be written as
// `curriedSum(1)(2)(3)`. After `numArgs` have been passed in, invoke the
// original `fn` with the accumulated arguments, using `object` as the
// context.

// function myCurry(fn, object, numArgs) {
//     let argarr = [];
//     let ofunc = fn;
//     return function _curry(...args) {
//         argarr.push(...args)
//         if (argarr.length < numArgs) return _curry;
//         return object.fn(...argarr);
//     }
// }

function myCurry(func, object, num) {
    let argarr = [];
    return function _curry(...args) {
        argarr.push(...args);
        if (argarr.length < num) return _curry;
        return func.call(object, ...argarr);
    }
}
