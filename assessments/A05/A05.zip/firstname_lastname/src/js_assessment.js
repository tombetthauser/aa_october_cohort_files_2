// Write a function, `uniqueSubstrings(string)`, that returns an array
// containing the unique substrings of `string`.


// Write an Array method, `Array.prototype.myEach(callback)`, that passes each 
// element to `callback` before returning the original array. Do NOT call the 
// built-in `Array.prototype.forEach` method in your implementation.


// Write an Array method, `Array.prototype.myFilter(callback)`, that returns an 
// array made up of the elements in the original array for which `callback` 
// returns `true`. Use the `Array.prototype.myEach` method you defined above. 
// Do NOT call the built-in `Array.prototype.forEach` or `Array.prototype.filter` 
// methods in your implementation.


// Write a function `pairMatch(array, callback)`. It should return all pairs
// of indices ([i, j]) for which `callback(array[i], array[j])` returns true.
// NB: Keep in mind that the order of the arguments to the callback may matter.
// e.g., callback = function(a, b) { return a < b }


// Write an Array method, `Array.prototype.bubbleSort(callback)`, that bubble 
// sorts an array. It should take an optional callback which compares two 
// elements, returning -1 if the first element should appear before the second, 
// 0 if they are equal, and 1 if the first element should appear after the second. 
// Do NOT call the built-in Array.prototype.sort method in your implementation. 
// Also, do NOT modify the original array.
//
// Here's a quick summary of the bubble sort algorithm:
//
// Iterate over the elements of the array. If the current element is unsorted
// with respect to the next element, swap them. If any swaps are made before
// reaching the end of the array, repeat the process. Otherwise, return the
// sorted array.


// Write a Function method, `Function.prototype.myBind(context, bindArgs)`. It
// should return a copy of the original function, where `this` is set to `context`.


// Write a Function method, `Function.prototype.inherits(ParentClass)`. It 
// should extend the methods of `ParentClass.prototype` to the constructor 
// function it is called on.


// Write a function, `myCurry(fn, object, numArgs)`, that curries the
// function. Remember that a curried function is invoked with one argument at a
// time. For example, the curried form of `sum(1, 2, 3)` would be written as
// `curriedSum(1)(2)(3)`. After `numArgs` have been passed in, invoke the
// original `fn` with the accumulated arguments, using `object` as the
// context.