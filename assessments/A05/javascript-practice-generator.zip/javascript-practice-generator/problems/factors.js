// Write a function, `factors(num)`, that returns an array containing the factors
// of a number in ascending order.
