// Write an `Array.prototype.myReject(callback)` method. Return a new array,
// which contains only the elements for which the callback returns false. 
// Use the `Array.prototype.myEach` method you defined above. Do NOT call the 
// built-in `Array.prototype.filter` or `Array.prototype.forEach` methods.
// ex.
// [1,2,3].myReject( (el) => el > 2 ) => [1, 2]
Array.prototype.myReject = function (callback) {
  const selection = [];

  this.myEach(el => {
    if (!callback(el)) {
      selection.push(el);
    }
  });

  return selection;
};
