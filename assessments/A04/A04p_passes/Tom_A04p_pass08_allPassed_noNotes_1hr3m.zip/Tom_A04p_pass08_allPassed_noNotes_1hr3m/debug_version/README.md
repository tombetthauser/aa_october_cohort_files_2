## Buggy Rails 2 Prep

Download the [zipfile][zip] of the buggy version of the practice assessment.

[zip]: ./skeleton.zip?raw=true
