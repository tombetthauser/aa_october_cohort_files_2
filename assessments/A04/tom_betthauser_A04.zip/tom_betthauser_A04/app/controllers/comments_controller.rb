class CommentsController < ApplicationController

    before_action :require_login

    def create
        @comment = Comment.new(comment_params)
        @comment.user_id = current_user.id
        @comment.product_id = params[:product_id]
        @comment.save

        flash[:errors] = @comment.errors.full_messages
        redirect_to product_url(@comment.product_id)
    end

    def destroy
        @comment = current_user.authored_comments.find(params[:id])
        @comment.destroy
        redirect_to product_url(@comment.product_id)
    end

    def comment_params
        params.require(:comment).permit(:body)
    end

end
