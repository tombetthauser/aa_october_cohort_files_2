class ProductsController < ApplicationController

    before_action :require_login

    def index
        @products = Product.all
    end

    def show
        @product = Product.find(params[:id])
    end

    def new
        @product = Product.new
    end

    def create
        @product = Product.new(product_params)
        @product.user_id = current_user.id
        if @product.save
            redirect_to product_url(@product)
        else
            flash.now[:errors] = @product.errors.full_messages
            render :new
        end
    end

    def edit
        @product = current_user.products.find(params[:id])
    end

    def update
        @product = current_user.products.find(params[:id])
        if @product.update_attributes(product_params)
            redirect_to product_url(@product)
        else
            flash.now[:errors] = @product.errors.full_messages
            render :edit
        end
    end

    def product_params
        params.require(:product).permit(:title, :description, :price)
    end

end
