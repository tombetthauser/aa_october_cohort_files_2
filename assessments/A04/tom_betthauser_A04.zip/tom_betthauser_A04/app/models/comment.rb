class Comment < ApplicationRecord

    validates :body, :product_id, :user_id, presence: true

    belongs_to :product
    belongs_to :author,
        class_name: :User,
        foreign_key: :user_id

end
