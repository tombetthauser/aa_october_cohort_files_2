FactoryBot.define do
  factory :post_sub do
    post_id {1}
    sub_id {1}
  end
end
