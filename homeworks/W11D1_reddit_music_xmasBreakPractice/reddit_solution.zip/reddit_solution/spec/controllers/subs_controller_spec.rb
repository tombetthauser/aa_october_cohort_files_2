require 'rails_helper'

RSpec.describe SubsController, type: :controller do

end
