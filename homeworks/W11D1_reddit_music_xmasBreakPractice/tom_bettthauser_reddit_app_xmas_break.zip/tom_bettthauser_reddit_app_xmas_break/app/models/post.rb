class Post < ApplicationRecord

    validates :title, :subs, presence: true
  
    belongs_to :author,
        class_name: :User,
        foreign_key: :user_id,
        inverse_of: :posts

    has_many :comments
    has_many :post_subs, dependent: :destroy
    has_many :subs, through: :post_subs, source: :sub

    def parent_comments
        parent_comments = Hash.new { |hash, key| hash[key] = [] }
        comments.includes(:author).each do |comment|
            parent_comments[comment.parent_comment_id] += [comment]
        end
        parent_comments
    end
    
end
