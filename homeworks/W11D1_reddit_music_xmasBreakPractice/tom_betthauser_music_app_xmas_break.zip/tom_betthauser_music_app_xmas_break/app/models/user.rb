class User < ApplicationRecord

    validates :email, :password_digest, :session_token, :activation_token, presence: true
    validates :password, length: { minimum: 6, allow_nil: true }
    
    validates :activation_token, :email, :session_token, uniqueness: true

    attr_reader :password
    has_many :notes

    after_initialize :ensure_session_token
    after_initialize :set_token

    def self.find_by_credentials(email, password)
        user = User.find_by(email: email)
        user && user.is_password?(password) ? user : nil
    end

    def set_token
        activation_token = activation_token_generate
    end

    def password=(password)
        @password = password
        password_digest = BCrypt::Password.create(password)
    end

    def is_password?(password)
        BCrypt::Password.new(self.password_digest).is_password?(password)
    end

    def reset_session_token!
        session_token = session_token_generate
        save!
        session_token
    end

    def ensure_session_token
    session_token ||= session_token_generate
    end

    def session_token_generate
    token = SecureRandom.urlsafe_base64
    while self.class.exists?(session_token: token)
        token = SecureRandom.urlsafe_base64(16)
    end
    token
    end

    def activation_token_generate
        token = SecureRandom.urlsafe_base64
        while self.class.exists?(activation_token: token)
            token = SecureRandom.urlsafe_base64(16)
        end
        token
    end

    def activate!
        update_attribute(:activated, true)
    end

end
