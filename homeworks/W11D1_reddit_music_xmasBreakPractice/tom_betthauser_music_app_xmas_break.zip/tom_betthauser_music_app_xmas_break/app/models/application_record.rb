class ApplicationRecord < ActiveRecord::Base
    self.abstract_class = true

    def generate_token_for_field(field)
        token = SecureRandom.urlsafe_base64
        while self.class.exists?(field => token)
            token = SecureRandom.urlsafe_base64
        end
        token
    end

end
