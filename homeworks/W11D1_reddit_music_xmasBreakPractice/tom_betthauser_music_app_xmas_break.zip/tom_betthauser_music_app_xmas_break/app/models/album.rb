class Album < ApplicationRecord
    
    validates :band, :year, :name, presence: true

    validates :name, uniqueness: { scope: :band_id }
    validates :live, inclusion: { in: [true, false] }
    validates :year, numericality: { minimum: 1900, maximum: 9000 }

    has_many :tracks, dependent: :destroy
    belongs_to :band  

    after_initialize :set_defaults

    def set_defaults
        live ||= false
    end

end
