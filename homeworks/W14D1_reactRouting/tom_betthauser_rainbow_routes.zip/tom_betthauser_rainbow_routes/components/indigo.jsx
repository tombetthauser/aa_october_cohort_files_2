import React from 'react';

const Indigo = () => (
  <div>
    <h3 className="indigo"></h3>
  </div>
);

export default Indigo;
