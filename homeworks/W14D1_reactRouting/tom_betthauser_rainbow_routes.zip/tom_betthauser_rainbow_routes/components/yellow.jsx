import React from 'react';

const Yellow = () => (
  <div>
    <h3 className="yellow"></h3>
  </div>
);

export default Yellow;
