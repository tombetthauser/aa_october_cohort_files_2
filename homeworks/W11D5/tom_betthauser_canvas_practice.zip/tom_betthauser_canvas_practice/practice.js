document.addEventListener("DOMContentLoaded", function(){
    const canvasEl = document.getElementById("mycanvas");

    canvasEl.width = 1000;
    canvasEl.height = 500;

    const ctx = canvasEl.getContext("2d");
    ctx.fillStyle = "black";
    ctx.fillRect(0, 0, 1000, 500);

    ctx.beginPath();

    ctx.arc(500, 275, 50, 0, 1 * Math.PI, true);

    ctx.fillStyle = "pink";
    ctx.fill();
});
