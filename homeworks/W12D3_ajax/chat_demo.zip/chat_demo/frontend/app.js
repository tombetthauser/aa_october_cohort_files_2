//js goes here :)
var ChatMachine = require("./ChatMachine.js");

$(function(){
  new ChatMachine($('.chat'));
});
