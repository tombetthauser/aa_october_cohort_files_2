/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = "./frontend/todo_redux.jsx");
/******/ })
/************************************************************************/
/******/ ({

/***/ "./frontend/todo_redux.jsx":
/*!*********************************!*\
  !*** ./frontend/todo_redux.jsx ***!
  \*********************************/
/*! no exports provided */
/***/ (function(module, exports) {

throw new Error("Module build failed (from ./node_modules/babel-loader/lib/index.js):\nSyntaxError: /Users/tombetthauser/Desktop/app_academy/aa_october_cohort_files_2/homeworks/W13D3_thunk/solution_1/frontend/todo_redux.jsx: Identifier 'store' has already been declared (8:8)\n\n\u001b[0m \u001b[90m  6 | \u001b[39m\u001b[0m\n\u001b[0m \u001b[90m  7 | \u001b[39m\u001b[36mfunction\u001b[39m addLoggingToDispatch(store) {\u001b[0m\n\u001b[0m\u001b[31m\u001b[1m>\u001b[22m\u001b[39m\u001b[90m  8 | \u001b[39m  \u001b[36mconst\u001b[39m store \u001b[33m=\u001b[39m store\u001b[33m.\u001b[39mdispatch\u001b[0m\n\u001b[0m \u001b[90m    | \u001b[39m        \u001b[31m\u001b[1m^\u001b[22m\u001b[39m\u001b[0m\n\u001b[0m \u001b[90m  9 | \u001b[39m  \u001b[36mreturn\u001b[39m \u001b[36mfunction\u001b[39m(action) {\u001b[0m\n\u001b[0m \u001b[90m 10 | \u001b[39m    console\u001b[33m.\u001b[39mlog(store\u001b[33m.\u001b[39mgetState())\u001b[0m\n\u001b[0m \u001b[90m 11 | \u001b[39m    console\u001b[33m.\u001b[39mlog(action)\u001b[0m\n    at Object.raise (/Users/tombetthauser/Desktop/app_academy/aa_october_cohort_files_2/homeworks/W13D3_thunk/solution_1/node_modules/@babel/parser/lib/index.js:7013:17)\n    at ScopeHandler.checkRedeclarationInScope (/Users/tombetthauser/Desktop/app_academy/aa_october_cohort_files_2/homeworks/W13D3_thunk/solution_1/node_modules/@babel/parser/lib/index.js:4289:12)\n    at ScopeHandler.declareName (/Users/tombetthauser/Desktop/app_academy/aa_october_cohort_files_2/homeworks/W13D3_thunk/solution_1/node_modules/@babel/parser/lib/index.js:4255:12)\n    at Object.checkLVal (/Users/tombetthauser/Desktop/app_academy/aa_october_cohort_files_2/homeworks/W13D3_thunk/solution_1/node_modules/@babel/parser/lib/index.js:8831:22)\n    at Object.parseVarId (/Users/tombetthauser/Desktop/app_academy/aa_october_cohort_files_2/homeworks/W13D3_thunk/solution_1/node_modules/@babel/parser/lib/index.js:11331:10)\n    at Object.parseVar (/Users/tombetthauser/Desktop/app_academy/aa_october_cohort_files_2/homeworks/W13D3_thunk/solution_1/node_modules/@babel/parser/lib/index.js:11306:12)\n    at Object.parseVarStatement (/Users/tombetthauser/Desktop/app_academy/aa_october_cohort_files_2/homeworks/W13D3_thunk/solution_1/node_modules/@babel/parser/lib/index.js:11128:10)\n    at Object.parseStatementContent (/Users/tombetthauser/Desktop/app_academy/aa_october_cohort_files_2/homeworks/W13D3_thunk/solution_1/node_modules/@babel/parser/lib/index.js:10725:21)\n    at Object.parseStatement (/Users/tombetthauser/Desktop/app_academy/aa_october_cohort_files_2/homeworks/W13D3_thunk/solution_1/node_modules/@babel/parser/lib/index.js:10658:17)\n    at Object.parseBlockOrModuleBlockBody (/Users/tombetthauser/Desktop/app_academy/aa_october_cohort_files_2/homeworks/W13D3_thunk/solution_1/node_modules/@babel/parser/lib/index.js:11234:25)\n    at Object.parseBlockBody (/Users/tombetthauser/Desktop/app_academy/aa_october_cohort_files_2/homeworks/W13D3_thunk/solution_1/node_modules/@babel/parser/lib/index.js:11221:10)\n    at Object.parseBlock (/Users/tombetthauser/Desktop/app_academy/aa_october_cohort_files_2/homeworks/W13D3_thunk/solution_1/node_modules/@babel/parser/lib/index.js:11205:10)\n    at Object.parseFunctionBody (/Users/tombetthauser/Desktop/app_academy/aa_october_cohort_files_2/homeworks/W13D3_thunk/solution_1/node_modules/@babel/parser/lib/index.js:10220:24)\n    at Object.parseFunctionBodyAndFinish (/Users/tombetthauser/Desktop/app_academy/aa_october_cohort_files_2/homeworks/W13D3_thunk/solution_1/node_modules/@babel/parser/lib/index.js:10190:10)\n    at withTopicForbiddingContext (/Users/tombetthauser/Desktop/app_academy/aa_october_cohort_files_2/homeworks/W13D3_thunk/solution_1/node_modules/@babel/parser/lib/index.js:11364:12)\n    at Object.withTopicForbiddingContext (/Users/tombetthauser/Desktop/app_academy/aa_october_cohort_files_2/homeworks/W13D3_thunk/solution_1/node_modules/@babel/parser/lib/index.js:10533:14)\n    at Object.parseFunction (/Users/tombetthauser/Desktop/app_academy/aa_october_cohort_files_2/homeworks/W13D3_thunk/solution_1/node_modules/@babel/parser/lib/index.js:11363:10)\n    at Object.parseFunctionStatement (/Users/tombetthauser/Desktop/app_academy/aa_october_cohort_files_2/homeworks/W13D3_thunk/solution_1/node_modules/@babel/parser/lib/index.js:11006:17)\n    at Object.parseStatementContent (/Users/tombetthauser/Desktop/app_academy/aa_october_cohort_files_2/homeworks/W13D3_thunk/solution_1/node_modules/@babel/parser/lib/index.js:10696:21)\n    at Object.parseStatement (/Users/tombetthauser/Desktop/app_academy/aa_october_cohort_files_2/homeworks/W13D3_thunk/solution_1/node_modules/@babel/parser/lib/index.js:10658:17)\n    at Object.parseBlockOrModuleBlockBody (/Users/tombetthauser/Desktop/app_academy/aa_october_cohort_files_2/homeworks/W13D3_thunk/solution_1/node_modules/@babel/parser/lib/index.js:11234:25)\n    at Object.parseBlockBody (/Users/tombetthauser/Desktop/app_academy/aa_october_cohort_files_2/homeworks/W13D3_thunk/solution_1/node_modules/@babel/parser/lib/index.js:11221:10)\n    at Object.parseTopLevel (/Users/tombetthauser/Desktop/app_academy/aa_october_cohort_files_2/homeworks/W13D3_thunk/solution_1/node_modules/@babel/parser/lib/index.js:10589:10)\n    at Object.parse (/Users/tombetthauser/Desktop/app_academy/aa_october_cohort_files_2/homeworks/W13D3_thunk/solution_1/node_modules/@babel/parser/lib/index.js:12192:10)\n    at parse (/Users/tombetthauser/Desktop/app_academy/aa_october_cohort_files_2/homeworks/W13D3_thunk/solution_1/node_modules/@babel/parser/lib/index.js:12243:38)\n    at parser (/Users/tombetthauser/Desktop/app_academy/aa_october_cohort_files_2/homeworks/W13D3_thunk/solution_1/node_modules/@babel/core/lib/parser/index.js:54:34)\n    at parser.next (<anonymous>)\n    at normalizeFile (/Users/tombetthauser/Desktop/app_academy/aa_october_cohort_files_2/homeworks/W13D3_thunk/solution_1/node_modules/@babel/core/lib/transformation/normalize-file.js:93:38)\n    at normalizeFile.next (<anonymous>)\n    at run (/Users/tombetthauser/Desktop/app_academy/aa_october_cohort_files_2/homeworks/W13D3_thunk/solution_1/node_modules/@babel/core/lib/transformation/index.js:31:50)");

/***/ })

/******/ });
//# sourceMappingURL=bundle.js.map