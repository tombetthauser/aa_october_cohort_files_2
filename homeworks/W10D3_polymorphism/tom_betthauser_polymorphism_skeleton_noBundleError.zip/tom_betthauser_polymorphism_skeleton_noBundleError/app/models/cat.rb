class Cat < ApplicationRecord
end
