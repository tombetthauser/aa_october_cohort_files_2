class Corgi < ApplicationRecord
end
