const Util = require("./utils.js");
const MovingObject = require("./moving_object.js");

const defaults = {
  COLOR: "black",
  RADIUS: 50
}

console.log('wassssuuuppp');


function Asteroid(options) {
  options = options || {}
  options.pos = options.pos || Game.randomPosition
  options.vel = options.vel || Util.randomVec(10)
  options.col = options.col || defaults.COLOR
  options.rad = options.rad || defaults.RADIUS
  MovingObject.call(this, options)
}

Util.inherits(Asteroid, MovingObject)


module.exports = Asteroid;
