const Asteroid = require("./asteroid.js");
const Util = require("./utils.js");
const MovingObject = require("./moving_object.js");

function Game() {
  this.DIM_X;
  this.DIM_Y;
  this.NUM_ASTEROIDS = 10;
  this.asteroids = [];
  this.addAsteroids();
}

Game.prototype.addAsteroids = function() {
    var that = this;
    for(let i = 0; i < this.NUM_ASTEROIDS; i++) {
        this.asteroids.push(new Asteroid({
            game: that,
            pos: this.randomPosition(),
            vel: Util.randomVec(10)
        }))
    }
}

Game.prototype.randomPosition = function() {
  return [Math.floor(Math.random() * 250), Math.floor(Math.random() * 150)]
}

Game.prototype.draw = function(ctx) {
  var canvas = document.getElementById("game-canvas");
  var ctx = canvas.getContext("2d");
  ctx.clearRect(0, 0, window.innerWidth, window.innerHeight);
  this.asteroids.forEach(el => {el.draw()})
}

Game.prototype.moveObjects = function () {
  this.asteroids.forEach(el => {el.move()})
}

Game.prototype.wrap = function(pos) {
    // return [(pos[0] % window.innerWidth), (pos[1] % window.innerHeight)];
    if (pos[0] < 0) pos[0] = window.innerWidth;
    if (pos[1] < 0) pos[1] = window.innerHeight;
    if (pos[0] > window.innerWidth) pos[0] = 0;
    if (pos[1] > window.innerHeight) pos[1] = 0;
    return pos;
}

Game.prototype.checkCollisions = function () {
//   for(let i = 0; i < this.asteroids.length - 1; i++) {
//       for(let j = i + 1; j < this.asteroids.length; j++) {
//           if (this.asteroids[i].isCollidedWith(this.asteroids[j])) {
//               console.log('boom')
//           }
//       }
//   }
}

Game.prototype.step = function() {
    this.moveObjects();
    this.draw();
    this.checkCollisions();
}

module.exports = Game;
