const Asteroid = require("./asteroid.js");
const Util = require("./utils.js");
const MovingObject = require("./moving_object.js");
const Game = require("./game.js");

function GameView(Game) {
    var canvas = document.getElementById("game-canvas");
    this.ctx = canvas.getContext("2d");
    this.game = Game;
    this.ship;
}

GameView.prototype.start = function() {
    var that = this;
  window.setInterval(function() {
      that.game.step()
  }, 20)
}

module.exports = GameView