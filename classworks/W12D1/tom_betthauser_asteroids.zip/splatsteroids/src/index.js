const MovingObject = require("./moving_object.js");
const Asteroid = require("./asteroid.js");
const Game = require("./game.js");
const GameView = require("./game_view.js");



window.MovingObject = MovingObject;
window.Asteroid = Asteroid;
window.Game = Game;
window.GameView = GameView;


window.addEventListener("DOMContentLoaded", function () {
    var canvas = document.getElementById("game-canvas");
    var ctx = canvas.getContext("2d");
    ctx.canvas.width = window.innerWidth;
    ctx.canvas.height = window.innerHeight;  
    const buns = new Game
    const hot = new GameView(buns)
    hot.start()
})


console.log("Webpack is working!")