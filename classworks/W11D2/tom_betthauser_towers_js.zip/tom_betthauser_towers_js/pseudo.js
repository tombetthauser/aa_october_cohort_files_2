class Towers {
    run() {
        // until original peg is empty and until a different peg is full/in order
        // get origin and target pegs from player
        // move top ring from origin to target peg
    }
}