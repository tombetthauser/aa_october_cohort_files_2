const readline = require('readline');

const reader = readline.createInterface({
  input: process.stdin,
  output: process.stdout
});

function Game() {
  this.towers = [[1, 2, 3], [], []];
}

Game.prototype.promptMove = function(callback) {
  console.log(`${JSON.stringify(this.towers)}`);
  reader.question("Enter origin and target pegs (i.e. 0, 1):", function (answer) {

    let parsed = answer.split(", ");
    parsed[0] = parseInt(parsed[0]);
    parsed[1] = parseInt(parsed[1]);

    callback(parsed);
    reader.close();
  });
}

Game.prototype.isValidMove = function(origin, target) {
    return this.towers[origin];
}



const game = new Game();
game.promptMove(console.log);