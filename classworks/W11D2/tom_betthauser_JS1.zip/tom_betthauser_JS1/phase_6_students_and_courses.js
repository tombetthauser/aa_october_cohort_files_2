function Student(first, last) {
  this.first = first;
  this.last = last;
  this.courses = [];
}

Student.prototype.name = function() {
  return `${this.first} ${this.last}`;
}

Student.prototype.enroll = function(course) {
  if (!(this.courses.includes(course))) {
    // this.hasConflict(course);
    this.courses.forEach(c => {
        if (c.conflictsWith(course)) {
            throw "Course conflict!";
        }
    });
    this.courses.push(course);
    course.addStudent(this);
  }
}

Student.prototype.courseLoad = function() {
  // returns hash of depts. (key), credits that student is taking in that dept. (value)
  let hash = {};

  this.courses.forEach( course => {
    if (hash[course.dept] !== undefined) {
      hash[course.dept] += course.credNum;
    } else {
      hash[course.dept] = course.credNum;
    }
  });
  return hash;
}

Student.prototype.hasConflict = function(course) {
    this.courses.forEach(c => {
        if (c.conflictsWith(course)) {
            throw "Course conflict!";
        }
    });
}






function Course(name, dept, credNum, timeBlock, days ) {
  this.name = name;
  this.dept = dept;
  this.credNum = credNum;
  this.timeBlock = timeBlock;
  this.days = days;
  this.students = [];
}

Course.prototype.addStudent = function(student) {
    if ( this.students.indexOf(student) === -1 ) {
        this.students.push(student);
        student.enroll(this);
    }
}

Course.prototype.conflictsWith = function(course) {
    return this.timeBlock === course.timeBlock;
    // if (!(this.timeBlock === course.timeBlock)) { return false; }
    // return this.days.some(day => { course.days.indexOf(day) !== -1 })
}





const days = ['mon', 'wed', 'fri']

const student1 = new Student('Alice', 'Smith');
const student2 = new Student('Bob', 'Smith');
const student3 = new Student('Ted', 'Smith');

const math = new Course('algebra', 'math', 4, 1, days);
const english = new Course('literature', 'english', 5, 1, ['mon']);
const science = new Course('chemistry', 'science', 3, 2, ['wed']);

student1.enroll(math);
student1.enroll(english);
// console.log(`${JSON.stringify(student1.courseLoad())}`);

// math.addStudent(student2);
// console.log(`${JSON.stringify(student2.courseLoad())}`);

// console.log(`${math.conflictsWith(english)}`)

console.log(`${math.conflictsWith(english)}`)
console.log(`${math.conflictsWith(science)}`)
// math.conflictsWith(english);
// math.conflictsWith(science);