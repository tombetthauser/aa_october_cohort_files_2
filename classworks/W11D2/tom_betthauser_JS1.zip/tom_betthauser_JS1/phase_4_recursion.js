const range = (start, end) => {
  if (start === end) { return [start]; }
  let nextNum = start + 1;
  let firstNum = [start];
  return firstNum.concat(range(nextNum, end));
}

// console.log(`${range(1, 2)}`);

const sumRec = (arr) => {
  if (arr.length === 0) { 
    return 0; 
  } else if (arr.length === 1) { 
    return arr[0] 
  }
  return arr[0] + sumRec(arr.slice(1, arr.length));
}

// console.log(`${sumRec([5, 1, 2])}`);

const exponent = (base, exp) => {
  if (exp === 1) { return base; }
  return base * exponent(base, exp - 1);
}

// console.log(`${exponent(2, 4)}`);


const fibonacci = (n) => {
    if ( n < 3 ) {
        return [0, 1].slice(0,n);
    }
    let fibs = fibonacci(n-1);
    let nextNum = fibs[fibs.length - 1] + fibs[fibs.length - 2];
    fibs.push(nextNum);
    return fibs;
}

// console.log(`${fibonacci(5)}`)


const deepDup = (arr) => {
    if ( !(arr instanceof Array) ) { return arr; }
    return arr.map( ele => { return deepDup(ele); } )
}

// console.log(`${deepDup([1,2,[3]])}`)


const bSearch = (arr, target) => {
    let middleIndex = arr.length / 2;
    let foundIndex = 0;

    if ( arr.length === 0 ) { return -1; }
    if ( arr[middleIndex] === target ) { return middleIndex; }

    let left = arr.slice(0, middleIndex);
    let right = arr.slice(middleIndex, arr.length);

    if ( target < arr[middleIndex] ) { 
        foundIndex = bSearch(left, target);
    } else {
        foundIndex = bSearch(right, target) + middleIndex;
    }

    return foundIndex;
}

// console.log(`${bSearch([1,2,3,4], 4)}`)


const mergeSort = (arr) => {
    if ( arr.length < 2 ) { return arr; }
    let middleIndex = arr.length / 2;
    let left = mergeSort(arr.slice(0, middleIndex));
    let right = mergeSort(arr.slice(middleIndex, arr.length));
    return merge(left, right);
}

const merge = (left, right) => {
    let merged = [];
    while (left.length > 0 && right.length > 0) {
        let nextItem = (left[0] < right[0]) ? left.shift() : right.shift();
        merged.push(nextItem);
    }
    return merged.concat(left, right);
}

// console.log(`${mergeSort([4,4,1,2,3])}`)

const subSets = (arr) => {
    if ( arr.length === 0 ) { return [[]]; }
    let firstEle = arr[0];
    let remainingEle = subSets(arr.slice(1));
    let withFirstEle = remainingEle.map( ele => [firstEle].concat(ele) );
    return remainingEle.concat(withFirstEle);
}

// console.log(`${JSON.stringify(subSets([1,3,4]))}`)