const testFunc = num => {
  console.log(num * 2);
};

const testFunc2 = num => {
  return num * 2;
};

Array.prototype.myEach = function(callback) {
  for (let i = 0; i < this.length; i++) {
    callback(this[i]);
  }
}


// console.log(`${[1, 2].myEach(testFunc)}`);
// console.log([1, 2].myEach(testFunc));

Array.prototype.myMap = function(callback) {
  let mapped = [];
//   for (let i = 0; i < this.length; i++) {
//     mapped.push(callback(this[i]));
//   }
  this.myEach(ele => { mapped.push(callback(ele)); });
  return mapped;
}

// console.log([1, 2].myMap(testFunc2));

Array.prototype.myReduce = function(callback, acc) {
  let startPos = 0;
  if (acc === undefined) {
    acc = this[0];
    startPos++;
  }
  for (let i = startPos; i < this.length; i++) {
    acc = callback(acc, this[i]);
  }
  return acc;
}

// // without initialValue
// console.log([1, 2, 3].myReduce(function(acc, el) {
//   return acc + el;
// })); // => 6

// // with initialValue
// console.log([1, 2, 3].myReduce(function(acc, el) {
//   return acc + el;
// }, 25)); // => 31

