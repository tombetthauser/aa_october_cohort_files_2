const kitty = new Cat('Roger', 'Trevor');
const kitty2 = new Cat('Garfield', 'Bob');

function Cat(name, owner) {
  this.name = name;
  this.owner = owner;
}

Cat.prototype.cuteStatement = function() {
  return `${this.owner} loves ${this.name}`;
}

Cat.prototype.cuteStatement = function () {
  return `Everyone loves ${this.name}`;
}

Cat.prototype.meow = function() {
  return 'meow';
}

kitty.meow = function() {
  return 'woof';
}

console.log(`${kitty.meow()}`); // => 'woof'
console.log(`${kitty2.meow()}`); // => 'meow'
