Array.prototype.uniq = function() {
    let uniq = [];
    for(let i = 0; i < this.length; i++) {
        if (uniq.indexOf(this[i]) === -1) {
            uniq.push(this[i]);
        }
    }
    return uniq;
}

// console.log(`${[1,1,2,3].uniq()}`);

Array.prototype.toSum = function() {
    let pairs = [];
    for(let i = 0; i < this.length; i++) {
        for(let j = i+1; j < this.length; j++) {
            if (this[i] + this[j] === 0) {
                pairs.push([i, j]);
            }
        }
    }
    return pairs;
}

// console.log(`${[1,-1,2,3].toSum()}`);

Array.prototype.transpose = function() {
    const matrix = Array.from({length: this[0].length}, () => Array.from({length: this.length}));
    for(let i = 0; i < this.length; i++) {
        for(let j = 0; j < this[i].length; j++) {
            matrix[j][i] = this[i][j];
        }
    }
    return matrix;
}

// console.log(`${[[1,2],[3,4]].transpose()}`)