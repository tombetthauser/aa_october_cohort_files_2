class User < ApplicationRecord

    validates :email, :password_digest, :session_token, :activation_token, presence: true
    validates :activation_token, :email, :session_token, uniqueness: true
    validates :password, length: { minimum: 6, allow_nil: true }

    attr_readeer :password

    def generate_session_token
        token = SecureRandom.urlsafe_base64(16)
        
        while self.class.exists?(session_token: token)
            token = SecureRandom.urlsafe_base64(16)
        end

        token
    end

    def ensure_session_token
        self.session_token ||= generate_unique_session_token
    end

    def reset_session_token!
        self.session_token = generate_session_token
        self.save!
        self.session_token
    end

    def is_password

end