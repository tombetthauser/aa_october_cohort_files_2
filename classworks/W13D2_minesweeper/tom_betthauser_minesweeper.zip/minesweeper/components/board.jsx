import React from "react";
import Tile from "./tile";

class Board extends React.Component{
    
    constructor(props){
        super(props);
        this.updateGame = this.props.updateGame;
    }
    
    render() { 
        const rows = this.props.board.grid.map((row, idx) => (
            <div key={idx} className="row">
                {console.log(this.updateGame)}
                {row.map((tile, idx) => <Tile key={idx} tile={tile} updateGame={this.updateGame} />)}
            </div>
        ))
        return (
            <div>
                {rows}
            </div>
        )
    }
}

export default Board;