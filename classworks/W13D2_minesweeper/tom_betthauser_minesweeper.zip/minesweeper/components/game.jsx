import React from 'react';
import Board from './board';
import * as Minesweeper from '../minesweeper';

class Game extends React.Component{

    constructor(props){
        super(props);
        // const size = prompt("Enter a board size.")
        this.state = { board: new Minesweeper.Board(10, 10)};
        this.updateGame = this.updateGame.bind(this);
        // this.explore = 
    }

    updateGame(tile, flaggingTile){
        if (flaggingTile) {
            tile.toggleFlag()
        } else {
            // tile.explore()
        }
    }

    render(){
        // console.log(this.state.board)
        return (
            <Board board={this.state.board} updateGame={this.updateGame}/>
        );
    }

    
}

export default Game;