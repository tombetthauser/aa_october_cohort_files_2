import React from 'react';
import * as Minesweeper from '../minesweeper';


class Tile extends React.Component{

    constructor(props){
        super(props);
        // this.explore = this.props.tile.explore();
        this.handleClick = this.handleClick.bind(this);
        // this.updateGame = this.props.updateGame;
        // console.log(props)
    }

    handleClick() {
        // this.explore();
        // this.updateGame();
    }

    render(){
        if ( this.explored === true && this.adjacentBombcount() > 1){
            return (<span>({ `${this.adjacentBombcount}` })</span>)
        } else if ( this.explored === true && this.bombed === true){
            return (<span> 💣 </span>)
        } else if ( this.explored === false && this.flagged === true){
            return (<span> 🚩 </span>)
        } else {
            return (<span onClick={this.handleClick} > 💣 </span>)
        }
    } 
}



export default Tile;