# This file should contain all the record creation needed to seed the database with its default values.
# The data can then be loaded with the rails db:seed command (or created alongside the database with db:setup).
#
# Examples:
#
#   movies = Movie.create([{ name: 'Star Wars' }, { name: 'Lord of the Rings' }])
#   Character.create(name: 'Luke', movie: movies.first)
ActiveRecord::Base.transaction do
  Cat.destroy_all
  colors = ['blue', 'black', 'brown', 'orange', 'white'] 
  Cat1 = Cat.create!(name: "John", color: colors[0], birth_date: '2014/02/01', sex: 'M', description: 'Blue cat')
  Cat2 = Cat.create!(name: "George", color: colors[1], birth_date: '2013/02/02', sex: 'F', description: 'Black cat')
  Cat3 = Cat.create!(name: "Anne", color: colors[2], birth_date: '2011/02/03', sex: 'M', description: 'Brown cat')
  Cat5 = Cat.create!(name: "Mark", color: colors[3], birth_date: '1927/02/05', sex: 'F', description: 'Orange cat')
  Cat4 = Cat.create!(name: "Jeff", color: colors[4], birth_date: '2008/02/04', sex: 'F', description: 'White cat')
end


#
# Table name: cats
#
#  id          :integer(8)      not null, primary key
#  birth_date  :date            not null
#  color       :string          not null
#  name        :string          not null
#  sex         :string(1)       not null
#  description :text            not null
