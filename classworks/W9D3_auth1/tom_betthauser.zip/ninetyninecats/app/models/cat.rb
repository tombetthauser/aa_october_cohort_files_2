
# == Schema Information
#
# Table name: cats
#
#  id          :integer(8)      not null, primary key
#  birth_date  :date            not null
#  color       :string          not null
#  name        :string          not null
#  sex         :string(1)       not null
#  description :text            not null
#

class Cat < ApplicationRecord
  validates :birth_date, presence: true
  validates :name, presence: true
  validates :color, presence: true, inclusion: { in: ['blue', 'black', 'brown', 'orange', 'white'] }
  validates :sex, presence: true, inclusion: { in: ['M', 'F'] }
  validates :description, presence: true

  def age
    birth_year = self.birth_date.year
    Date.today.year - birth_year
  end

end