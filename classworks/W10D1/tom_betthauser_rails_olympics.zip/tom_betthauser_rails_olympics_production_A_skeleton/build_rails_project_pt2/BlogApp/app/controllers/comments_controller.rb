class CommentsController < ApplicationController

    def create
        new_comment = Comment.create(new_comment_params)
        new_comment.save
        redirect_to blog_url(new_comment_params[:blog_id])
    end

    def destroy
        doomed_comment = Comment.find(params[:id])
        doomed_comment.destroy
        redirect_to blog_url(doomed_comment[:blog_id])
    end

    def new_comment_params
        params.require(:comment).permit(:body, :author_id, :blog_id)
    end
    
end
