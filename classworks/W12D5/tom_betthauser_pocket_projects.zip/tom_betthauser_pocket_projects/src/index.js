import warmUp from "./warmup";
import clock from "./clock";
import drop_down from "./drop_down";
import todo_list from "./todo_list";

// import {htmlGenerator} from "./warmup";
// const partyHeader = document.getElementById('party');
// htmlGenerator('Party Time.', partyHeader);