let todos = [];

const u = document.getElementsByClassName("todos")[0];
const f = document.getElementsByClassName("add-todo-form")[0];

const addTodo = function() {
    // Find the input with the name add - todo and set's it's value to a variable
    const i = document.getElementById("todo-input");
    const userInput = i.value;

    const newTodoHTML = document.createElement("li");
    newTodoHTML.innerHTML = userInput;

    alert(userInput)
    u.appendChild(newTodoHTML);

    const newTodoObj = {text: userInput, done: false};
    todos.push(newTodoObj);

    i.value = "";    
}

const s = document.getElementById("todo-submit");
s.addEventListener('click', addTodo);

const populateList = function (todos) {
//   todos.
};