class SessionsController < ApplicationController

    def create
        user = User.find_by_credentials(params[:user][:username], params[:user][:password])
        if user
            session[:session_token] = user.session_token
            flash[:success] = "welcome back #{user.username}"
            redirect_to cats_url
        else
            flash[:error] = "wrong email / password"
            render :new, status: 401
        end
    end

    def new
        render :new
    end

end