const DOMNodeCollection = require("./dom_node_collection");
window.DOMNodeCollection = DOMNodeCollection;

function callback(arg) {
    if (arg instanceof HTMLElement) {
        return 'html'
    } else if (arg instanceof String) {
        return 'string'
    }
}

window.$l = (arg) => {

    if (callback(arg) === 'html') {
        arr = document.getElementsByTagName(arg);
    } else {
        arr = document.querySelectorAll(arg);
    }

    return newNodeSet = new DOMNodeCollection(arr);
}


        // document.addEventListener("DOMContentLoaded", function () {}); 
        // ?????

// empty, remove, attr, addClass, removeClass, html, find, children, and parent

// document.addEventListener("DOMContentLoaded", function () {
// });

// alert("cat");
