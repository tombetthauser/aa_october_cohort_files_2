function DOMNodeCollection(arr) {
    this.arr = arr;
}

DOMNodeCollection.prototype.empty = function () {
    // console.log(this.arr)
    for (let i = 0; i < this.arr.length; i++) {
        let node = this.arr[i];
        node.innerHTML = "";
    }
 }

DOMNodeCollection.prototype.html = function (input) {
    for (let i = 0; i < this.arr.length; i++) {
        let node = this.arr[i];
        node.innerHTML = input;
    }
 }

DOMNodeCollection.prototype.append = function (input) {



    // console.log(this.arr[0].nodeName);
    // this.arr.map(el => {
    //     // maybe slicing it?
    //     // look for < or > and slice inbetween?
    // })
    
    const node = document.createElement(this.arr[0].nodeName);
    const textnode = document.createTextNode(input);
    node.appendChild(textnode);
    // alert(this.arr.length);
    this.arr[this.arr.length - 1].appendChild(node);

    // var p = document.createElement("p");
    // document.body.appendChild(p);

    // for (let i = 0; i < this.arr.length; i++) {
    //     console.log(this.arr[i]);
    //     let node = this.arr[i];
    //     node.appendChild(input);
    // }
 }

// var node = document.createElement("LI");                 // Create a <li> node
// var textnode = document.createTextNode("Water");         // Create a text node
// node.appendChild(textnode);                              // Append the text to <li>
// document.getElementById("myList").appendChild(node);     // Append <li> to <ul> with id="myList" 

const handleFavoriteSubmit = (e) => {
    e.preventDefault();
    const favoriteInput = document.querySelector(".favorite-input");
    const favorite = favoriteInput.value;
    favoriteInput.value = "";

    const newListLi = document.createElement("li");
    newListLi.textContent = favorite;

    const favoritesList = document.getElementById("sf-places");
    favoritesList.appendChild(newListLi);
};





 const dommy = new DOMNodeCollection([1, 2, 3]);
module.exports = DOMNodeCollection;

// remove, attr, addClass, removeClass, find, children, and parent